---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 陨石粉
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# 陨石粉

<ItemImage id="sky_dust" scale="4" />

被<ItemLink id="inscriber" />粉碎的<ItemLink id="sky_stone_block" />。用于制造<ItemLink id="cell_component_256k" />和<ItemLink id="sky_stone_block" />。

也可通过在世界高度上限向上放置<ItemLink id="annihilation_plane" />获得。

## 配方

<RecipeFor id="sky_dust" />
